from django.contrib import admin
from login.models import Login
from login.models import Contact


# Register your models here.
admin.site.register(Login)
admin.site.register(Contact)
